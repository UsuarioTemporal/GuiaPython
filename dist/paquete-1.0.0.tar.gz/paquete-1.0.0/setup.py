from setuptools import setup
#paquetes distribuibles
setup(
    name="paquete",
    version="1.0.0",
    description="paquete de repasos",
    author="Thom",
    author_email="thomtwd@gmail.com",
    url="https://github.com/UsuarioTemporal/RepasoPython",
    packages=["repaso4","repaso4"]
)